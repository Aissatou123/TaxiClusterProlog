%NOM: DIOME
%Pr�nom: A�ssatou Kangou
%ID: 300139476


%pr�dicat qui importe nos partitions. D�j� fournit
import:-
    csv_read_file('partition65.csv', Data65, [functor(partition)]),maplist(assert, Data65),
    csv_read_file('partition74.csv', Data74, [functor(partition)]),maplist(assert, Data74),
    csv_read_file('partition75.csv', Data75, [functor(partition)]),maplist(assert, Data75),
    csv_read_file('partition76.csv', Data76, [functor(partition)]),maplist(assert, Data76),
    csv_read_file('partition84.csv', Data84, [functor(partition)]),maplist(assert, Data84),
    csv_read_file('partition85.csv', Data85, [functor(partition)]),maplist(assert, Data85),
    csv_read_file('partition86.csv', Data86, [functor(partition)]),maplist(assert, Data86),listing(partition).

%pr�dicat qui renvoie le ni�me �l�ment d'une liste
nieme(1,[X|_],X) :- !.
nieme(N,[_|R],X) :- N1 is N-1, nieme(N1,R,X).


% d�finition de clusterList comme liste comportant des cluster qui sont
% aussi des listes
clusterList([]):-[[],[]].

%definition de partion en identifiant chaque �l�ment de la liste
%mais aussi cr�er notre liste de cluster si jamais y a intersection

partiition(PARTITION_ID, POINT_ID, X, Y, CLUSTER_ID):- nth0(K,import,J),
    PARTITION_ID=nieme(1,J,PARTITION_ID),
    POINT_ID=nieme(2,J,POINT_ID),
    X=nieme(3,J,X),
    Y=nieme(4,J,Y),
    CLUSTER_ID=nieme(5,J,CLUSTER_ID),

    succ(K,1).

%pr�dicat qui r�alise l'intersection
intersect(A,B,I):- intersection(A,B,I).

%pr�dicat pour changer label
changeLabel(A,B):-A is B.


%pr�dicat pour faire l'union
unioon(A,B):- union(A,B,A).


%algorithme final qui r�alise le
mergeClusters(L):-nieme(I,import,P), %on accede � chaque partition
    nieme(5,P,C),  %on acc�de a chaque cluster
    nieme(2,P,D), %on acc�de au label du cluster
    intersect(C,clusterList,inter), %on fait l'intersection de notre cluster avec clusterList
    nieme(1,inter,lab),  %on acc�de au label de chaque cluster ici point_id
    changeLabel(lab,D), %changer le label dans clusterList par celui de Cluster dans partition
    L= unioon(C,clusterList), %on fait l'union pour avoir notre clusterList Final
   succ(I,1). % incr�mente I pour traverser toute notre liste import

%partie test
test(nieme):- write('nieme(3,[1,2,3,4,5,8],X)'),nl,nieme(3,[1,2,3,4,5,8],X).
test(intersect):-write('intersect([3,6,2,1,8,9],[1,2,3,4,5,8],I)'),nl,intersect([3,6,2,1,8,9],[1,2,3,4,5,8],I).
test(changeLabel):-write('changeLabel(3,4)'),nl,changeLabel(3,4).
test(unioon):-write('unioon([3,6,2,1,8,9],[1,2,3,4,5,8])'),nl,unioon([3,6,2,1,8,9],[1,2,3,4,5,8]).
test(mergeClusters):-write("mergeClusters(L),open('clusters.txt',write,F),write(F,L),close(F). "),nl,mergeClusters(L),open('clusters.txt',write,F),write(F,L),close(F),write(L).




%FIN DU PROGRAMME
